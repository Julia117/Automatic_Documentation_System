---
name: Feature Request
about: Suggest improvements to Harmony
title: ''
labels: enhancement
assignees: ''

---

## Description

A quick description of the requested feature.

## Rationale

A rationale for why the feature should be implemented in Harmony.